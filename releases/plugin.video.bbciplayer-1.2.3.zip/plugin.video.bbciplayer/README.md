# plugin.video.bbciplayer
BBC iPlayer for Kodi
Support: http://forum.kodi.tv/showthread.php?tid=239378
Author: CaptainT