# Brian Hornsby's Repository for Kodi
Repository for Brian Hornsby's Kodi add-ons and scripts. 
Add-ons: BBC iPlayer and TuneIn Radio. 
Scripts: OpenStreetMap, OpenVPN and SimilarTracks.