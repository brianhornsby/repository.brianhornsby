OpenStreetMap for Kodi
======================

A script that allows access to OpenStreetMap on Kodi.
